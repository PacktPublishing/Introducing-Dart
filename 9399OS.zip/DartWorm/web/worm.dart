library wormgame;

import 'dart:html';
import 'dart:math' as math;
import 'dart:async';

part "food.dart";
part "wormbody.dart";

Timer actionTimer;
math.Random rand = new math.Random();
List<Food> food = new List<Food>();
Element gameBoard;
Worm worm;
int width =  800;
int height = 600;

void main() {
  document.onKeyPress.listen(keyPressed);

  gameBoard = querySelector('#board');

  worm = new Worm(gameBoard, 40, 40, Worm.EAST);

  for (int i = 0; i < 10; i++) {
    Food f = new Food(rand.nextInt(width - 20),
        rand.nextInt(height - 20));
    gameBoard.children.add(f.element);
    f.show();
    food.add(f);
  }
  updateScore();
  startActionTimer();
}

void startActionTimer() {
  actionTimer = new Timer.periodic(new Duration(milliseconds: 300), onTimer);
}

void reset() {
  if (actionTimer.isActive) {
    actionTimer.cancel();
  }

  for (Element e in gameBoard.children) {
    if (e.id == 'worm' ||
        e.id == 'announcement' ||
        e.classes.contains('body')) {
      gameBoard.children.remove(e);
    }
  }

  worm = new Worm(gameBoard, 40, 40, Worm.EAST);
  updateScore();
  startActionTimer();
}

void keyPressed(KeyboardEvent e) {
  String key = new String.fromCharCode(e.charCode);

  if (key == "w") {
    worm.turnNorth();
  } else if (key == "s") {
    worm.turnSouth();
  } else if (key == "a") {
    worm.turnWest();
  } else if (key == "d") {
    worm.turnEast();
  } else if (key == "p") {
    if (actionTimer.isActive) {
      actionTimer.cancel();
    } else {
      startActionTimer();
    }
  } else if (key == "r") {
    reset();
  }
}

void onTimer(Timer t) {
  worm.redraw(null);

  if (worm.intersectsWithItself() || worm.outOfBounds()) {
    gameOver();
  }

  for (Food f in food) {
    if (worm.intersectsWith(f.element)) {
      worm.flicker();
      worm.growBody(3);
      f.hide();
      f.move(rand.nextInt(width - 20), rand.nextInt(height - 20));
      f.show();
      worm.score += 1;
      updateScore();
    }
  }

  if (worm.score >= 25) {
    youWin();
  }
}

void updateScore() {
  querySelector('#score').text = "${worm.score}";
  querySelector('#length').text = "${worm.length}";
}

void gameOver() {
  if (actionTimer.isActive) {
    actionTimer.cancel();
  }

  Element e = new Element.p();
  e.text = "Game Over";
  e.id = "announcement";
  gameBoard.children.add(e);
}

void youWin() {
  if (actionTimer.isActive) {
    actionTimer.cancel();
  }

  for (Element e in gameBoard.children) {
    gameBoard.children.remove(e);
  }

  Element e = new Element.p();
  e.text = "You Win!";
  e.id = "announcement";
  gameBoard.append(e);
}
